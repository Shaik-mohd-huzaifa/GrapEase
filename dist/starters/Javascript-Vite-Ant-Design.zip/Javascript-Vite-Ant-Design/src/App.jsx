import React from "react";
import { Button, Typography } from "antd";
import { CodeOutlined, AntDesignOutlined } from "@ant-design/icons";
import "./App.css";

function App() {
  return (
    <div className="app-container">
      <Typography.Title level={2}>Grafbase Starter Kit</Typography.Title>
      <Typography.Text>
        Customized with Vite & Ant Design
      </Typography.Text>

      <div className="config">
        <div className="config-item">
          <CodeOutlined />
          <Typography.Text>Vite</Typography.Text>
        </div>

        <div className="config-item">
          <AntDesignOutlined />
          <Typography.Text>Ant Design</Typography.Text>
        </div>
      </div>

      <Button type="primary">Start Developing</Button>
    </div>
  );
}

export default App;
