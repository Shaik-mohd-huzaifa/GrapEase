import React from "react";
import { Button, Container, Typography } from "@mui/material";
import { Code, DesignServices } from "@mui/icons-material";
import "./App.css";

function App() {
  return (
    <Container className="app-container">
      <Typography variant="h2">Grafbase Starter Kit</Typography>
      <Typography variant="subtitle1">
        Customized with Vite & Material UI
      </Typography>

      <div className="config">
        <div className="config-item">
          <Code />
          <Typography variant="subtitle2">Vite</Typography>
        </div>

        <div className="config-item">
          <DesignServices />
          <Typography variant="subtitle2">Material UI</Typography>
        </div>
      </div>

      <Button variant="contained" color="primary">
        Start Developing
      </Button>
    </Container>
  );
}

export default App;
